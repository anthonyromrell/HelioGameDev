﻿using UnityEditor;
using UnityEngine;
using System.IO;

namespace SimpleSQL
{
    static public class Menus
    {
        // GameObjects
        [MenuItem("Tools/SimpleSQL/Create SimpleSQL Database Manager")]
        [MenuItem("GameObject/Create Other/SimpleSQL/Database Manager")]
        static public void CreateSQLManager()
        {
            GameObject go;
            SimpleSQLManager manager;

            go = new GameObject("DB Manager");
            manager = (SimpleSQLManager)go.AddComponent(typeof(SimpleSQLManager));

            Selection.activeGameObject = go;
        }

        // "Assets" - really just creating files
        [MenuItem("Tools/SimpleSQL/Create Empty Database")]
        [MenuItem("Assets/Create/SimpleSQL/Empty Database")]
        static public void CreateEmptyDatabase()
        {
            EditorHelper.CreateAssetFromEmbeddedResource("SimpleSQL.Resources.template.bytes.resource", "New Database.bytes");
        }


        // Tools
        [MenuItem("Tools/SimpleSQL/Options")]
        static public void Options()
        {
            OptionsEditorWindow.ShowEditor();
        }

        //// Tools
        //[MenuItem("Tools/SimpleSQL/Add SQLite3.dll to Plugins")]
        //static public void AddSQLite3DLL()
        //{
        //    string pluginsPath = Path.Combine(Application.dataPath, "Plugins");

        //    if (!Directory.Exists(pluginsPath))
        //    {
        //        Directory.CreateDirectory(pluginsPath);
        //    }

        //    EditorHelper.CreateFileFromEmbeddedResource("SimpleSQL.sqlite3.dll.resource", Path.Combine(pluginsPath, "sqlite3.dll"));

        //    AssetDatabase.Refresh();
        //}
    }
}
